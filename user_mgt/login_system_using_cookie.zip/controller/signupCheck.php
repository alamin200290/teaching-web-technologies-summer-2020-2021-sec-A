<?php
	session_start();

	if(isset($_POST['submit'])){

		$username= $_REQUEST['username'];
		$password= $_POST['password'];
		$email= $_POST['email'];
		$type= $_POST['type'];

		if($username != '' && $password != '' && $email != ''){
			$user =['username'=> $username, 'password'=>$password, 'email'=>$email, 'type'=>$type];
			$_SESSION['user'] = $user;
			header('location: ../view/login.php');
		}else{
			header('location: ../view/signup.php?msg=null');
		}
	}else{
		echo "invalid request...";
	}

?>